﻿using Microsoft.WindowsAzure.Storage.Table;
using System;
using EPAM.TableStorage;
using EPAM.TableStorage.Model;

namespace EPAM.TestClient
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Table Operation Started!");
            //Create Table If not Exists
            CloudTable table = AzureTableOperations.CreateTableAsync().Result;
            //Call webhCat Service bind the Response to ServiceLog Entity 

            ServiceLogEntity serviceLog = new ServiceLogEntity("hadoopCluster", "BadGateWay")
            {
                ErrorMessage = "No user found.  Missing user.name parameter."

            };
            Console.WriteLine("Create Table If Not Exist");
            AzureTableOperations.InsertLogs(table, serviceLog);

            //Console.WriteLine("Fetch The details From The table Storage");
           // AzureTableOperations.RetrieveOperationAsync(table, "hadoopCluster", "BadGateWay");

            Console.ReadLine();

        }
    }
}

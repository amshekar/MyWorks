﻿using Microsoft.WindowsAzure.Storage.Table;

namespace EPAM.TableStorage.Model
{
    public class ServiceLogEntity : TableEntity
    {
        public ServiceLogEntity() { }

        // Define the Partition Key and RowKey
        public ServiceLogEntity(string clusterName, string errorName)
        {
            this.PartitionKey = clusterName;
            this.RowKey = errorName;

        }
        public string ErrorMessage { get; set; }
    }
}

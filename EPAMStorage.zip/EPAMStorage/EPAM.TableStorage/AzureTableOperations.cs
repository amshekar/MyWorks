﻿using EPAM.TableStorage.Model;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Threading.Tasks;

namespace EPAM.TableStorage
{
    public static class AzureTableOperations
    {
        internal const string TableName = "ServiceLog";



        /// <summary>
        /// Create a table for the sample application to process messages in. 
        /// </summary>
        /// <returns>A CloudTable object</returns>
        public static async Task<CloudTable> CreateTableAsync()
        {
            // Retrieve storage account information from connection string.
            //CloudStorageAccount storageAccount = CreateStorageAccountFromConnectionString(Microsoft.Azure.CloudConfigurationManager.GetSetting("CloudStorageConnectionString"));
            CloudStorageAccount storageAccount = CreateStorageAccountFromConnectionString(Microsoft.Azure.CloudConfigurationManager.GetSetting("StorageConnectionString"));
            // Create a table client for interacting with the table service
            CloudTableClient tableClient = storageAccount.CreateCloudTableClient();

            Console.WriteLine("1. Create a Table for the demo");

            // Create a table client for interacting with the table service 
            CloudTable table = tableClient.GetTableReference(TableName);
            try
            {
                if (await table.CreateIfNotExistsAsync())
                {
                    Console.WriteLine("Created Table named: {0}", TableName);
                }
                else
                {
                    Console.WriteLine("Table {0} already exists", TableName);
                }
            }
            catch (StorageException)
            {
                Console.WriteLine("If you are running with the default configuration please make sure you have started the storage emulator. Press the Windows key and type Azure Storage to select and run it from the list of applications - then restart the sample.");
                Console.ReadLine();
                throw;
            }

            return table;
        }



        /// <summary>
        /// Validate the connection string information in app.config and throws an exception if it looks like 
        /// the user hasn't updated this to valid values. 
        /// </summary>
        /// <param name="storageConnectionString">Connection string for the storage service or the emulator</param>
        /// <returns>CloudStorageAccount object</returns>
        private static CloudStorageAccount CreateStorageAccountFromConnectionString(string storageConnectionString)
        {
            CloudStorageAccount storageAccount;
            try
            {
                storageAccount = CloudStorageAccount.Parse(storageConnectionString);
            }
            catch (FormatException)
            {
                Console.WriteLine("Invalid storage account information provided. Please confirm the AccountName and AccountKey are valid in the app.config file - then restart the application.");
                throw;
            }
            catch (ArgumentException)
            {
                Console.WriteLine("Invalid storage account information provided. Please confirm the AccountName and AccountKey are valid in the app.config file - then restart the sample.");
                Console.ReadLine();
                throw;
            }

            return storageAccount;
        }

        public static async Task InsertLogs(CloudTable table, ServiceLogEntity entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException("entity");
            }
            TableOperation insertOperation = TableOperation.Insert(entity);
            await table.ExecuteAsync(insertOperation);
        }

        public static async Task<ServiceLogEntity> RetrieveOperationAsync(CloudTable table, string partitionKey, string rowKey)
        {
            TableOperation retrieveOperation = TableOperation.Retrieve<ServiceLogEntity>(partitionKey, rowKey);
            TableResult result = await table.ExecuteAsync(retrieveOperation);
            ServiceLogEntity serviceLog = result.Result as ServiceLogEntity;
            if (serviceLog != null)
            {
                Console.WriteLine("\t{0}\t{1}\t{2}\t{3}", serviceLog.PartitionKey, serviceLog.RowKey, serviceLog.ErrorMessage);
            }

            return serviceLog;
        }


        public static async Task<ServiceLogEntity> GetServiceLogs()
        {
            //CloudStorageAccount storageAccount = CreateStorageAccountFromConnectionString(Microsoft.Azure.CloudConfigurationManager.GetSetting("CloudStorageConnectionString"));
            CloudStorageAccount storageAccount = CreateStorageAccountFromConnectionString(Microsoft.Azure.CloudConfigurationManager.GetSetting("StorageConnectionString"));
            CloudTableClient client = storageAccount.CreateCloudTableClient();
            CloudTable table = client.GetTableReference(TableName);
            table.CreateIfNotExists();
            TableOperation getLogOp = TableOperation.Retrieve<ServiceLogEntity>("test","test");
            TableResult getLogResults = table.Execute(getLogOp);
            return getLogResults.Result as ServiceLogEntity;
        }

      
    }
}
